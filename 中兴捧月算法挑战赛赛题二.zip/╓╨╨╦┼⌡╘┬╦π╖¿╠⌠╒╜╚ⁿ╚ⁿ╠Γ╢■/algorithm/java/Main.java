import java.io.*;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        File file = new File("../data/");
        File[] listFiles = file.listFiles();
        List<Integer[]> flows = null;
        List<Integer[]> ports = null;
        List<Integer[]> ans = null;
        List<Integer[]> invokeQueue = null;
        List<Integer[]> storeQueue = null;
        File tempFile = null;
        String flowPath = null;
        String portPath = null;
        String resultPath = null;
        for (int k = 0; k < listFiles.length; k++) {
            tempFile = listFiles[k];
            String path = tempFile.getPath();
            flowPath = path + "/flow.txt";
            portPath = path + "/port.txt";
            resultPath = path + "/result.txt";
            flows = readTxt(flowPath);
            ports = readPorts(portPath);
            int invokeSize = ports.size() * 20;
            int portSizeLimit = 30;
            Map<Integer,LinkedList<Integer[]>> map = new HashMap<>();
            for (Integer[] port : ports) {
                map.put(port[0],new LinkedList<>());
            }
            flows.sort((o1, o2) -> o1[2] - o2[2]);
            ans = new ArrayList<>(5000);
            invokeQueue = new ArrayList<>();
            storeQueue = new ArrayList<>();
            int curTime = 0;
            int startIndex = 0;
            do {
                for (int i = 0; i < storeQueue.size(); i++) {
                    Integer[] nextFlow = storeQueue.get(i);
                    if (nextFlow[3] <= curTime) {
                        for (Integer[] port : ports) {
                            if (port[0] == nextFlow[0]) {
                                port[2] = port[2] + nextFlow[1];
                                break;
                            }
                        }
                        storeQueue.remove(i);
                        i--;
                    }
                }
                for (Integer[] port : ports) {
                    LinkedList<Integer[]> waitQueue = map.get(port[0]);
                    while(!waitQueue.isEmpty()) {
                        Integer[] waitFlow = waitQueue.getFirst();
                        if(waitFlow[1]>port[2])
                            break;
                        port[2] = port[2] - waitFlow[1];
                        Integer[] strings = new Integer[4];
                        strings[0] = port[0];
                        strings[1] = waitFlow[1];
                        strings[2] = waitFlow[0];
                        Integer expireTime = curTime + waitFlow[3];
                        strings[3] = expireTime;
                        storeQueue.add(strings);
                        waitQueue.removeFirst();
                    }
                }
                while (startIndex < flows.size()) {
                    Integer[] flow = flows.get(startIndex);
                    if (flow[2]>curTime)
                        break;
                    invokeQueue.add(flow);
                    startIndex = startIndex + 1;
                }
                invokeQueue.sort(new Comparator<Integer[]>() {
                    @Override
                    public int compare(Integer[] o1, Integer[] o2) {
                        if(o1[3] - o2[3]>0)
                            return 1;
                        else if(o1[3] - o2[3]<0)
                            return -1;
                        else return o1[1] - o2[1];
                    }
                });
                for (int i = 0; i < invokeQueue.size(); i++) {
                    Integer[] invokeFlow = invokeQueue.get(i);
                    Integer[] targetPort = null;
                    for (Integer[] port : ports) {
                        if(port[1]>=invokeFlow[1]&&port[2]>=invokeFlow[1]){
                            if (targetPort == null) {
                                targetPort = port;
                            }else{
                                if(targetPort[2]>port[2])
                                    targetPort = port;
                            }
                        }
                    }
                    if(targetPort==null){
                        Integer[] waitPort = null;
                        Integer waitSize = null;
                        for (Integer[] port : ports) {
                            LinkedList<Integer[]> waitQueue = map.get(port[0]);
                            if(waitQueue.size()<portSizeLimit&&port[1]>=invokeFlow[1]){
                                if (waitPort == null) {
                                    waitPort = port;
                                    waitSize = waitQueue.size();
                                }else{
                                    if(waitSize>waitQueue.size()){
                                        waitPort = port;
                                        waitSize = waitQueue.size();
                                    }
                                }
                            }
                        }
                        if (waitPort == null) {
                            if (invokeQueue.size()<=invokeSize) {
                                break;
                            }
                            Integer[] resId = null;
                            for (Integer[] port : ports) {
                                if(port[1]>=invokeFlow[1]){
                                    if (resId == null) {
                                        resId = port;
                                    }else{
                                        if(resId[1]<=port[1]){
                                            resId = port;
                                        }
                                    }
                                }
                            }
                            Integer[] result = new Integer[3];
                            result[0] = invokeFlow[0];
                            result[1] = resId[0];
                            result[2] = curTime;
                            ans.add(result);
                            invokeQueue.remove(i);
                            i--;
                        }else{
                            LinkedList<Integer[]> queue = map.get(waitPort[0]);
                            queue.addLast(invokeFlow);
                            Integer[] result = new Integer[3];
                            result[0] = invokeFlow[0];
                            result[1] = waitPort[0];
                            result[2] = curTime;
                            ans.add(result);
                            invokeQueue.remove(i);
                            i--;
                        }
                    }else{
                        Integer[] strings = new Integer[4];
                        strings[0] = targetPort[0];
                        strings[1] = invokeFlow[1];
                        strings[2] = invokeFlow[0];
                        Integer expireTime = curTime + invokeFlow[3];
                        strings[3] = expireTime;
                        storeQueue.add(strings);
                        targetPort[2] = targetPort[2] - invokeFlow[1];
                        Integer[] result = new Integer[3];
                        result[0] = invokeFlow[0];
                        result[1] = targetPort[0];
                        result[2] =curTime;
                        ans.add(result);
                        invokeQueue.remove(i);
                        i--;
                    }
                }
                curTime++;
            } while (!storeQueue.isEmpty() || !invokeQueue.isEmpty());
            outputFile(resultPath, ans);
        }
    }

    public static List<Integer[]> readTxt(String filePath) {
        BufferedReader bf = null;
        String str = null;
        File file = new File(filePath);
        ArrayList<Integer[]> dataSet = new ArrayList<>();
        Integer[] temp = null;
        int index = 0;
        try {
            bf = new BufferedReader(new FileReader(file));
            bf.readLine();
            while ((str = bf.readLine()) != null) {
                String[] s = str.split(",");
                temp = new Integer[s.length];
                index = 0;
                for (String s1 : s) {
                    temp[index++] = Integer.parseInt(s1);
                }
                dataSet.add(temp);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bf != null) {
                try {
                    bf.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return dataSet;
    }

    public static List<Integer[]> readPorts(String filePath) {
        BufferedReader bf = null;
        String str = null;
        File file = new File(filePath);
        List<Integer[]> dataSet = new ArrayList<>();
        Integer[] temp = null;
        int index = 0;
        try {
            bf = new BufferedReader(new FileReader(file));
            bf.readLine();
            while ((str = bf.readLine()) != null) {
                String[] s = str.split(",");
                temp = new Integer[s.length + 1];
                index = 0;
                for (String s1 : s) {
                    temp[index++] = Integer.parseInt(s1);
                }
                temp[index] = Integer.parseInt(s[s.length-1]);
                dataSet.add(temp);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bf != null) {
                try {
                    bf.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return dataSet;
    }

    public static void outputFile(String resultPath, List<Integer[]> data) {
        File file = new File(resultPath);
        BufferedWriter bw = null;
        StringBuilder ss = new StringBuilder();
        try {
            bw = new BufferedWriter(new FileWriter(file));
            for (Integer[] item : data) {
                if (item.length > 0) {
                    for (int i = 0; i < item.length; i++) {
                        ss.append(item[i]);
                        ss.append(",");
                    }
                    ss.deleteCharAt(ss.length() - 1);
                    ss.append("\n");
                }
            }
            bw.write(ss.toString());
            bw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

