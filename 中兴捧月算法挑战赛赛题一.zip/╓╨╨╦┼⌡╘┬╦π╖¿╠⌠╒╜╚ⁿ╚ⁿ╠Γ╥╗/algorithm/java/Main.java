//package algorithm;
import java.io.*;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        String dirPath = "../data/";
        File file = new File(dirPath);
        File[] listFiles = file.listFiles();
     
        for (File listFile : listFiles) {
        
            String path = listFile.getPath();
            String flowPath = path + "/flow.txt";
            String portPath = path  + "/port.txt";
            String resultPath = path + "/result1.txt";
            List<String[]> flows = readTxt(flowPath);
            Collections.sort(flows, new Comparator<String[]>() {
                @Override
                public int compare(String[] o1, String[] o2) {
                    return Integer.parseInt(o1[2]) - Integer.parseInt(o2[2]);
                }
            });
            List<String[]> ports = readTxt(portPath);
//            int maxBandwidth = 0;
//            for(String[] port:ports){
//                if(maxBandwidth<Integer.parseInt(port[1]))
//                    maxBandwidth = Integer.parseInt(port[1]);
//            }
            List<String[]> ans = new ArrayList<>();
            List<String[]> invokeQueue = new ArrayList<>();
            List<String[]> storeQueue = new ArrayList<>();
            int curTime = 0;
            do{
                Iterator<String[]> sqIter = storeQueue.iterator();
                while(sqIter.hasNext()){
                    String[] nextFlow = sqIter.next();
                    if(Integer.parseInt(nextFlow[3])==curTime){
                        for (String[] port : ports) {
                            if(Integer.parseInt(port[0])==Integer.parseInt(nextFlow[0])){
                                port[1] = String.valueOf(Integer.parseInt(port[1]) + Integer.parseInt(nextFlow[1]));
                                break;
                            }
                        }
                        sqIter.remove();
                    }
                }
                Iterator<String[]> it = flows.iterator();
                while(it.hasNext()){
                    String[] flow = it.next();
                    if(Integer.parseInt(flow[2])==curTime){
                        invokeQueue.add(flow);
                        it.remove();
                    }
                }
                Iterator<String[]> iterator = invokeQueue.iterator();
                while(iterator.hasNext()) {
                    String[] invokeFlow = iterator.next();
                    for (String[] port : ports) {
                        if(Integer.parseInt(invokeFlow[1])<Integer.parseInt(port[1])){
                            String[] strings = new String[4];
                            strings[0] = port[0];
                            strings[1] = invokeFlow[1];
                            strings[2] = invokeFlow[0];
                            strings[3] = String.valueOf(curTime + Integer.parseInt(invokeFlow[3]));
                            storeQueue.add(strings);
                            port[1] = String.valueOf(Integer.parseInt(port[1]) - Integer.parseInt(invokeFlow[1]));
                            String[] result = new String[3];
                            result[0] = invokeFlow[0];
                            result[1] = port[0];
                            result[2] = String.valueOf(curTime+1);
                            ans.add(result);
                            iterator.remove();
                            break;
                        }
                    }
                }
                curTime++;
            }while(!storeQueue.isEmpty()||!invokeQueue.isEmpty());

            outputFile(resultPath, ans);

        }
    }
    public static List<String[]> readTxt(String filePath){
        BufferedReader bf = null;
        String str = null;
        File file = new File(filePath);
        ArrayList<String[]> dataSet = new ArrayList<>();
        try {
            bf = new BufferedReader(new FileReader(file));
            str = bf.readLine();
            while((str=bf.readLine())!=null)
            {
                String[] s=str.split(",");
                dataSet.add(s);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataSet;
    }
    public static void outputFile(String resultPath,List<String[]> data){
        File file = new File(resultPath);
        BufferedWriter bw = null;
        StringBuilder ss =null;
        try {
            bw = new BufferedWriter(new FileWriter(file));
            for (String[] item : data) {
                ss = new StringBuilder();
                if(item.length>0){
                    for (int i = 0; i < item.length; i++) {
                        ss.append(item[i]);
                        ss.append(",");
                    }
                    ss.deleteCharAt(ss.length()-1);
                    bw.write(ss.toString() + "\r\n");
                }
            }
            bw.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(bw!=null){
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
