```java
//判断当前节点是否在同步队列当中
final boolean isOnSyncQueue(Node node) {
    //1.如果当前节点的waitStatus是Condition，则表明当前节点不在同步队列当中
   	//2.如果当前节点的waitStatus不是Condition,那么也就是当前节点的状态是Cancelled，当前节点取消等待了。那么需要查看当前节点
    //的前驱节点是否为null，如果为null表明当前节点处于Cancelled并且仍然在条件队列中
    if (node.waitStatus == Node.CONDITION || node.prev == null)
        return false;
    //走到这一步说明node.pre!=null,那么如果node.next!=null说明只能是在同步队列了，同步队列才会同时使用pre和next
    if (node.next != null) // If has successor, it must be on queue
        return true;
    /*
     * node.prev can be non-null, but not yet on queue because
     * the CAS to place it on queue can fail. So we have to
     * traverse from tail to make sure it actually made it.  It
     * will always be near the tail in calls to this method, and
     * unless the CAS failed (which is unlikely), it will be
     * there, so we hardly ever traverse much.
     */
    //走到这一步说明node.pre!=null&&node.next==null;
    那么node节点有可能是在同步队列的尾部，具体需要从同步队列的尾部开始判断node是否真的在同步队列中
    return findNodeFromTail(node);
}
private boolean findNodeFromTail(Node node) {
    Node t = tail;
    //从同步队列的尾部开始判断每个节点的情况，如果在同步队列中查找到node节点则返回true
    //否则返回false
    for (;;) {
        if (t == node)
            return true;
        if (t == null)
            return false;//同步队列遍历结束了
        t = t.prev;
    }
}

    /**
     * Invokes release with current state value; returns saved state.
     * Cancels node and throws exception on failure.
     * @param node the condition node for this wait
     * @return previous sync state
     */
//释放当前节点所占有的锁（包含重入）并返回同步装填state的值
final int fullyRelease(Node node) {
    boolean failed = true;
    try {
        int savedState = getState();
        if (release(savedState)) {//释放所有的同步状态state
            failed = false;
            return savedState;//返回state的值
        } else {
            //release->tryRelease重写时可能会出现异常的状况
            throw new IllegalMonitorStateException();
        }
    } finally {
        //出现异常时failed为true，执行该代码，将当前节点的waitStatus的值修改为Cancelled
        if (failed)
            node.waitStatus = Node.CANCELLED;
    }
}

//唤醒条件队列的首节点
public final void signal() {
    if (!isHeldExclusively())
        throw new IllegalMonitorStateException();
    Node first = firstWaiter;
    if (first != null)
        doSignal(first);
}
/**
* Removes and transfers nodes until hit non-cancelled one or
* null. Split out from signal in part to encourage compilers
* to inline the case of no waiters.
* @param first (non-null) the first node on condition queue
*/
private void doSignal(Node first) {
    do {
        if ( (firstWaiter = first.nextWaiter) == null)
            lastWaiter = null;
        first.nextWaiter = null;
       //transferForSignal如果返回false说明首节点已经取消了，需要从下一个节点开始唤醒
    } while (!transferForSignal(first) &&
             (first = firstWaiter) != null);
}

/**
* Transfers a node from a condition queue onto sync queue.
* Returns true if successful.
* @param node the node
* @return true if successfully transferred (else the node was
* cancelled before signal)
*/
final boolean transferForSignal(Node node) {
    /*
   	* If cannot change waitStatus, the node has been cancelled.
    */
    //如果cas失败表明节点已经被取消了，即node.waitStatus的值为Cancelled，返回false
    if (!compareAndSetWaitStatus(node, Node.CONDITION, 0))
        return false;
    /*
         * Splice onto queue and try to set waitStatus of predecessor to
         * indicate that thread is (probably) waiting. If cancelled or
         * attempt to set waitStatus fails, wake up to resync (in which
         * case the waitStatus can be transiently and harmlessly wrong).
         */
    //走到这里说明已经将node的waitStatus的值修改为0
    //将node节点加入到同步队列的队尾
    Node p = enq(node);
    int ws = p.waitStatus;
    //p是node的前驱节点，ws是前驱节点的状态值
    //如果前驱节点的状态值ws>0,即前驱节点是处于取消状态，则将唤醒node节点的线程，否则即ws<=0,
    使用cas修改p的状态，如果修改失败，说明p的状态值又被修改了，即p.waitStatus = 1，那还是唤醒node吧
    if (ws > 0 || !compareAndSetWaitStatus(p, ws, Node.SIGNAL))
        LockSupport.unpark(node.thread);
    return true;
}
```