1. **ArrayBlockingQueue**

   ```java
   //ArrayBlockingQueue构造方法
   public ArrayBlockingQueue(int capacity, boolean fair) {
       if (capacity <= 0)
           throw new IllegalArgumentException();
       this.items = new Object[capacity];
       lock = new ReentrantLock(fair);
       notEmpty = lock.newCondition();//创建实例变量时，初始化notEmpty
       notFull =  lock.newCondition();//创建实例变量时，初始化notFull
   }
   //向队列中插入元素，如果队列已满，则阻塞等待
   public void put(E e) throws InterruptedException {
       checkNotNull(e);
       final ReentrantLock lock = this.lock;
       lock.lockInterruptibly();
       try {
           while (count == items.length)
               notFull.await();
           enqueue(e);
       } finally {
           lock.unlock();
       }
   }
   //向队列中插入元素，插入成功则返回true,否则返回false;
   //非阻塞方式
   public boolean offer(E e) {
           checkNotNull(e);//如果为null,则抛出空指针异常
           final ReentrantLock lock = this.lock;
           lock.lock();
           try {
               if (count == items.length)
                   return false;//队列满，返回false
               else {
                   enqueue(e);入队
                   return true;
               }
           } finally {
               lock.unlock();
           }
       }
   public boolean add(E e) {
           return super.add(e);//调用AbstractQueue中的add方法
   }
   /*AbstractQueue中的方法*/
   public boolean add(E e) {
       if (offer(e))//插入成功则返回true
           return true;
       else//插入失败抛出Queue full
           throw new IllegalStateException("Queue full");
   }
   
   ```

2. LinkedBlockingQueue



一、构造器

```java
//无参构造器
public LinkedBlockingQueue() {
    this(Integer.MAX_VALUE);//调用有参构造器
}

public LinkedBlockingQueue(int capacity) {
    if (capacity <= 0) throw new IllegalArgumentException();
    this.capacity = capacity;//最大容量
    last = head = new Node<E>(null);//哑结点
}
//带有一个集合的有参构造器
public LinkedBlockingQueue(Collection<? extends E> c) {
        this(Integer.MAX_VALUE);//默认最大容量是Integer.MAX_VALUE
        final ReentrantLock putLock = this.putLock;//获取向阻塞队列放入数据的锁
        putLock.lock(); // Never contended, but necessary for visibility不会发生争抢，但是为了可见性，加锁是有必要的
        try {
            int n = 0;
            for (E e : c) {
                if (e == null)
                    throw new NullPointerException();
                if (n == capacity)
                    throw new IllegalStateException("Queue full");
                enqueue(new Node<E>(e));
                ++n;
            }
            count.set(n);// private final AtomicInteger count = new AtomicInteger();
        } finally {
            putLock.unlock();
        }
    }
```

二、常用方法

```java
public void put(E e) throws InterruptedException {
    if (e == null) throw new NullPointerException();
    // Note: convention in all put/take/etc is to preset local var
    // holding count negative to indicate failure unless set.
    int c = -1;
    Node<E> node = new Node<E>(e);
    final ReentrantLock putLock = this.putLock;
    final AtomicInteger count = this.count;
    putLock.lockInterruptibly();
    try {
        /*
         * Note that count is used in wait guard even though it is
         * not protected by lock. This works because count can
         * only decrease at this point (all other puts are shut
         * out by lock), and we (or some other waiting put) are
         * signalled if it ever changes from capacity. Similarly
         * for all other uses of count in other wait guards.
         */
        while (count.get() == capacity) {
            notFull.await();//防止并发情况下的虚假唤醒，所以使用while循环确保不会由于多线程的并发操作造成的虚假唤醒
        }
        enqueue(node);//当前插入的元素加入到对尾
        c = count.getAndIncrement();//获取到当前元素插入到对尾前队列中元素的数量
        if (c + 1 < capacity)
            notFull.signal();//如果插入后元素的数量小于最大容量，可以唤醒之前由于队列满时造成阻塞等待的线程
    } finally {
        putLock.unlock();
    }
    if (c == 0)
        signalNotEmpty();//如果插入当前元素前的元素数量是0，那么唤醒由于队列空时阻塞的线程
}
/*私有方法，唤醒由于队列空时的阻塞线程*/
private void signalNotEmpty() {
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lock();//先获取锁
        try {
            notEmpty.signal();//唤醒由于队列空时的阻塞线程
        } finally {
            takeLock.unlock();
        }
    }
/*从队列中取元素*/
public E take() throws InterruptedException {
        E x;
        int c = -1;
        final AtomicInteger count = this.count;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lockInterruptibly();
        try {
            while (count.get() == 0) {
                notEmpty.await();//如果队列元素为空，那么将当前线程阻塞在notEmpty条件变量当中
            }
            x = dequeue();//对头元素出队列
            c = count.getAndDecrement();
            if (c > 1)
                notEmpty.signal();//如果取出对头元素前队列中的数量大于1，那么唤醒由于之前队列空时阻塞的线程
        } finally {
            takeLock.unlock();
        }
        if (c == capacity)
            signalNotFull();//如果取走元素之前队列中的元素数量是capacity，那么当取走一个元素后可以唤醒由于之前队列中
    //元素数量达到最大时而阻塞的线程
        return x;
    }
/*poll方法和take方法的区别在于
1.poll方法在队列容量为0时，直接返回null
2.take方法在队列容量为0时，会阻塞等待
3.poll方法不响应中断，而take方法可以响应中断
take方法更适合用于生产者和消费者模型
*/
public E poll() {
        final AtomicInteger count = this.count;
        if (count.get() == 0)
            return null;
        E x = null;
        int c = -1;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lock();
        try {
            if (count.get() > 0) {
                x = dequeue();
                c = count.getAndDecrement();
                if (c > 1)
                    notEmpty.signal();
            }
        } finally {
            takeLock.unlock();
        }
        if (c == capacity)
            signalNotFull();
        return x;
    }
//带有等待时间的取出队列元素
//timeout表示等待的时间，如果超过timeout时间仍然没有获取到队列中的元素，则返回null
//否则返回队列中的第一个元素，该方法可以响应中断
public E poll(long timeout, TimeUnit unit) throws InterruptedException {
    E x = null;
    int c = -1;
    long nanos = unit.toNanos(timeout);
    final AtomicInteger count = this.count;
    final ReentrantLock takeLock = this.takeLock;
    takeLock.lockInterruptibly();
    try {
        while (count.get() == 0) {
            if (nanos <= 0)
                return null;
            nanos = notEmpty.awaitNanos(nanos);
        }
        x = dequeue();
        c = count.getAndDecrement();
        if (c > 1)
            notEmpty.signal();
    } finally {
        takeLock.unlock();
    }
    if (c == capacity)
        signalNotFull();
    return x;
}
//唤醒由于队列满时而阻塞的线程
private void signalNotFull() {
        final ReentrantLock putLock = this.putLock;
        putLock.lock();
        try {
            notFull.signal();
        } finally {
            putLock.unlock();
        }
    }
//获取队列的第一个元素
public E peek() {
        if (count.get() == 0)
            return null;
        final ReentrantLock takeLock = this.takeLock;
        takeLock.lock();//取锁
        try {
            Node<E> first = head.next;
            if (first == null)
                return null;
            else
                return first.item;
        } finally {
            takeLock.unlock();
        }
    }
public boolean remove(Object o) {
        if (o == null) return false;
        fullyLock();//删除元素需要获取双锁，即takeLock和putLock两把锁，如果只获得一把锁，在并发线程下，其他线程持有另一把
    //锁会将队列中元素作出改变。比如只持有一把takeLock，另一个线程持有了putLock，容易造成混乱
        try {
            for (Node<E> trail = head, p = trail.next;
                 p != null;
                 trail = p, p = p.next) {
                if (o.equals(p.item)) {
                    unlink(p, trail);
                    return true;
                }
            }
            return false;
        } finally {
            fullyUnlock();//释放双锁
        }
    }
/*将队列中的元素转化为Object数组*/
public Object[] toArray() {
        fullyLock();//获取双锁
        try {
            int size = count.get();//创建大小为size的数组存储队列中的元素
            Object[] a = new Object[size];
            int k = 0;
            for (Node<E> p = head.next; p != null; p = p.next)
                a[k++] = p.item;//遍历队列中的每个元素并且加入到Object数组中
            return a;
        } finally {
            fullyUnlock();
        }
    }
/*清空当前队列中的所有元素*/
public void clear() {
        fullyLock();
        try {
            for (Node<E> p, h = head; (p = h.next) != null; h = p) {
                h.next = h;
                p.item = null;
            }
            head = last;
            // assert head.item == null && head.next == null;
            if (count.getAndSet(0) == capacity)
                notFull.signal();//由于队列满而阻塞的线程被唤醒
        } finally {
            fullyUnlock();
        }
    }
```