一、为什么引入ThreadLocal

![image-20230520141507225](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230520141507225.png)

ThreadLocal可以解决跨方法参数传递问题，降低方法的耦合度。比如使用DbUtils（自定义的），那么可以使用工厂方法创建数据库连接对象Connection，每个线程都可以自己创建一个提供给当前线程访问，但是会出现其他方法需要使用Connection对象（比如使用Connection作为参数关闭连接）。这样就会造成其他方法依赖Connection参数，增加耦合度和复杂性。

而使用ThreadLocal可以解决跨方法传递参数的问题，也可以解决多线程对共享变量访问的并发性问题。

正是存在多线程对共享变量访问存在的线程安全问题以及局部变量在跨方法时存在参数传递的问题，才使用ThreadLocal解决这些问题。

ThreadLocal是一种用空间换时间的策略。

![image-20230520151940676](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230520151940676.png)

ThreadLocal的主要方法源码

ThreadLocal#set()

```java
public void set(T value) {
    Thread t = Thread.currentThread();//获取当前线程
    ThreadLocalMap map = getMap(t);//获取线程中的ThreadLocalMap变量
    if (map != null)
        map.set(this, value);//如果ThreadLocalMap非空，那么将键值对<ThreadLocal<?>,Object>存入ThreadLocalMap中
    else
        //ThreadLocalMap为null，则为当前线程创建ThreadLocalMap,并把<ThreadLocal<?>,Object>
        //存入到ThreadLocalMap当中
        createMap(t, value);
}
//ThreadLocalMap中的set方法
private void set(ThreadLocal<?> key, Object value) {

    // We don't use a fast path as with get() because it is at
    // least as common to use set() to create new entries as
    // it is to replace existing ones, in which case, a fast
    // path would fail more often than not.

    Entry[] tab = table;
    int len = tab.length;
    //获取key在Entry[] 中的槽点
    int i = key.threadLocalHashCode & (len-1);
	//找到key对应的槽点，如果该槽点是null，跳过for循环，否则存在冲突，使用线性探测方法解决冲突问题
    for (Entry e = tab[i];
         e != null;
         e = tab[i = nextIndex(i, len)]) {
        ThreadLocal<?> k = e.get();
		//覆盖旧值
        if (k == key) {
            e.value = value;
            return;
        }
		//走到这里说明k!=key，存在冲突，又k==null,说明该槽点上的key已经被回收了，那么直接将当前<key,value>替换原来的<null,Object>
        if (k == null) {
            replaceStaleEntry(key, value, i);
            return;
        }
    }
	//要么对应槽点不存在数据，没发生冲突；要么发生冲突了，使用线性探测找到了一个null的槽点
    tab[i] = new Entry(key, value);
    int sz = ++size;
    if (!cleanSomeSlots(i, sz) && sz >= threshold)
        rehash();
}
```

ThreadLocal#get()

```java
public T get() {
    Thread t = Thread.currentThread();
    ThreadLocalMap map = getMap(t);//获取当期线程中的ThreadLocalMap变量
    if (map != null) {
    //如果map不是null,则获取当前ThreadLocal对象所属的Entry对象
        ThreadLocalMap.Entry e = map.getEntry(this);
        if (e != null) {
        //如果Entry e不是null则，返回对应的value值
            @SuppressWarnings("unchecked")
            T result = (T)e.value;
            return result;
        }
    }
    //1.map为null
    //2.Entry e为null
    //e为null的情况，比如先调用set(value)方法，这样就先为当前线程创建一个ThreadLocalMap对象，然后使用remove()
    //方法将value从ThreadLocalMap中清除，这样就可以保证ThreadLocalMap中是一个容量为0的容器，再使用get方法获取值的
    //时候就会出现map不是null,但是 Entry e是null的情况。
    return setInitialValue();
}
//ThreadLocalMap中的方法，实际上ThreadLocal中的方法最终会调用到ThreadLocalMap中的方法
//ThreadLocalMap是真正存储值的容器
private T setInitialValue() {
    T value = initialValue();//获取初始值
    Thread t = Thread.currentThread();
    ThreadLocalMap map = getMap(t);
    if (map != null)
        map.set(this, value);
    else
        createMap(t, value);
    return value;
}
```

```java
/*
函数功能：清除所有的key为null的Entry
参数staleSlot:int Entry数组的下标
*/
private int expungeStaleEntry(int staleSlot) {
    Entry[] tab = table;
    int len = tab.length;

    //先清除key为null的Entry
    tab[staleSlot].value = null;
    tab[staleSlot] = null;
    size--;

    //遍历Entry数组清除其他key为null的Entry
    Entry e;
    int i;
    for (i = nextIndex(staleSlot, len);
         (e = tab[i]) != null;
         i = nextIndex(i, len)) {
        ThreadLocal<?> k = e.get();
        if (k == null) {
            //遍历到下一个Entry的key为null,删除该元素
            e.value = null;
            tab[i] = null;
            size--;
        } else {
            //当前Entry的key不为空，计算key的槽位和当前i是否相等
            int h = k.threadLocalHashCode & (len - 1);
            if (h != i) {
                //如果不相等，说明存在了hash冲突，直接把i置为null，为当前Entry重新查找槽位
                tab[i] = null;

                // Unlike Knuth 6.4 Algorithm R, we must scan until
                // null because multiple entries could have been stale.
                while (tab[h] != null)
                    h = nextIndex(h, len);
                tab[h] = e;//将Entry放入重新找到的槽位中
            }
        }
    }
    return i;
}
```

​                                                                       

