## AbstractQueuedSynchronier源码分析

**AbstractQueuedSynchronier是构成各种同步器组件的基础，很多同步器组件都依赖于AbstractQueuedSynchronier实现其功能，如ReentrantLock锁、Semaphore、CountDownLantch等。**

**下面以ReentrantLock中的AbstractQueuedSynchronier为例进行分析**

```java
//默认的构造方法使用的是非公平锁
public ReentrantLock() {
    sync = new NonfairSync();
}

/**
     * Creates an instance of {@code ReentrantLock} with the
     * given fairness policy.
     *
     * @param fair {@code true} if this lock should use a fair ordering policy
     */
//通过fair变量来控制使用公平锁还是非公平锁
public ReentrantLock(boolean fair) {
    sync = fair ? new FairSync() : new NonfairSync();
}
```

![image-20230817165702074](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230817165702074.png)

### 公平锁模式

- ​	**获取锁的流程**

```java
public void lock() {
    sync.lock();
}
//在公平锁模式下，sync = new FairSync();
//调用FairSync实现的lock()方法
final void lock() {
    acquire(1);
}
//此为AbstractQueuedSynchronier实现的通用方法，重点在tryAcquire的不同
public final void acquire(int arg) {
    if (!tryAcquire(arg) &&
        acquireQueued(addWaiter(Node.EXCLUSIVE), arg))
        //如果当前节点被中断过会进入到这个函数，其实就是打断一下自己，设置一下中断标记
        selfInterrupt();
}
//公平锁模式下，调用FairSync实现的tryAcquire
protected final boolean tryAcquire(int acquires) {
    final Thread current = Thread.currentThread();
    //获取到state的值，state的值表示锁是否被获取，state==0表示没有被抢占，state>0表示已经被抢占，有重入情况
    int c = getState();
    if (c == 0) {
        //公平锁讲究先来先服务原则，首先查看是否有别的线程已经在排队等待
        //如果没有线程排队，则谁用CAS乐观锁进行尝试将state的值修改，使用CAS是考虑到多线程的并发
        if (!hasQueuedPredecessors() &&
            compareAndSetState(0, acquires)) {
            setExclusiveOwnerThread(current);
            return true;
        }
    }
    //如果当前线程是抢到锁的线程，那么是重入的情况，将state的值+acquires
    else if (current == getExclusiveOwnerThread()) {
        int nextc = c + acquires;//重入
        if (nextc < 0)
            throw new Error("Maximum lock count exceeded");
        setState(nextc);
        return true;
    }
    //非上述两种情况，那么抢占锁失败
    return false;
}
}
//当线程抢占锁失败后，需要将当前线程构造成Node节点插入到队列尾部
private Node addWaiter(Node mode) {
    //构造节点
    Node node = new Node(Thread.currentThread(), mode);
    // Try the fast path of enq; backup to full enq on failure
    Node pred = tail;
    if (pred != null) {
        //tail不为空，那么将当前节点插入尾部
         //############重点############
        //节点插入到队列尾部是先指向前一个节点，之后再
        node.prev = pred;
        //   节点      节点
        //	 节点<-----节点
        //类似于这样哦，所以后面有从tail--->head的遍历情况
        if (compareAndSetTail(pred, node)) {
            pred.next = node;
            return node;
        }
    }
    //循环将node节点插入到队列中
    enq(node);
    return node;
}
//
private Node enq(final Node node) {
    //自旋锁把node节点加入到队列的尾部
    for (;;) {
        Node t = tail;
        //tail为null的情况，添加哑结点
        if (t == null) { // Must initialize
            if (compareAndSetHead(new Node()))
                tail = head;
        } else {
            node.prev = t;
            if (compareAndSetTail(t, node)) {
                t.next = node;
                return t;
            }
        }
    }
}
```

![image-20230816201110608](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230816201110608.png)

```html
从图中我们可以看到，addWaiter和enq方法插入节点的时候是先node的前驱指针指向前驱节点的，这也是为什么后面会有方法从tail-->head的遍历方式。
```

```java
//节点被插入到队列尾部后，该节点就会尝试获取锁，如果尝试获取锁失败后，节点线程会被阻塞，等待占用锁的线程唤醒后续节点
final boolean acquireQueued(final Node node, int arg) {
    boolean failed = true;
    try {
        boolean interrupted = false;
        for (;;) {
            //获取当前节点的前驱节点
            final Node p = node.predecessor();
            //如果当前节点的前驱是head，那么再尝试获取一次锁
            if (p == head && tryAcquire(arg)) {
                //当前节点设置为头，由当前获取到锁的节点线程将原头结点指针断掉
                setHead(node);
                p.next = null; // help GC
                failed = false;
                return interrupted;
            }
            //第一次进入shouldParkAfterFailedAcquire会返回false,主要是先将当前节点的前驱节点的waitStatus设置为SINGAL
            //下一次会进入到parkAndCheckInterrupt,当前节点被阻塞，LockSupport.park(this);如果节点被唤醒后，会返回在阻
            //塞期间是否被中断的标记，同时清除掉中断标记
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                interrupted = true;
        }
    } finally {
        if (failed)
            //ReentrantLock不会响应中断，一般不会走到这一步，但是可能会有方法重写tryAcquire()方法，可能会抛出异常
            cancelAcquire(node);
    }
}

private static boolean shouldParkAfterFailedAcquire(Node pred, Node node) {
    //pred前驱节点，node是当前节点
    int ws = pred.waitStatus;
    //如果当前前驱节点的waitStatus==SIGNAL，直接返回true,主要含义是将当前节点的前驱节点的waitStatus值设置为SINGAL,
    //由前驱节点负责唤醒当前节点
    if (ws == Node.SIGNAL)
        /*
             * This node has already set status asking a release
             * to signal it, so it can safely park.
             */
        return true;
    if (ws > 0) {
        /*
             * Predecessor was cancelled. Skip over predecessors and
             * indicate retry.
             */
        //前驱节点waitStatus>0，前驱节点取消了
        //那么，为node节点找到waitStatus<=0的节点进行连接
        //参看下图解释
        do {
            node.prev = pred = pred.prev;
        } while (pred.waitStatus > 0);
        pred.next = node;
    } else {
        /*
             * waitStatus must be 0 or PROPAGATE.  Indicate that we
             * need a signal, but don't park yet.  Caller will need to
             * retry to make sure it cannot acquire before parking.
             */
        //当前节点的前驱节点waitStatus==0,那么CAS设置前驱节点的waitStatus==SINGAL，负责唤醒后续节点
        //参看下图解释
        compareAndSetWaitStatus(pred, ws, Node.SIGNAL);
    }
    return false;
}
```

![image-20230816204539611](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230816204539611.png)

![image-20230816203730360](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230816203730360.png)

- **释放锁的流程**

```java
public void unlock() {
    sync.release(1);
}

public final boolean release(int arg) {
    if (tryRelease(arg)) {
        //释放成功，那么h==null,那么当前线程占用锁的时候，到后续释放的没有其他线程抢占锁，队列为空
        Node h = head;
        if (h != null && h.waitStatus != 0)
            //释放锁的节点唤醒后续节点
            unparkSuccessor(h);
        return true;
    }
    return false;
}

protected final boolean tryRelease(int releases) {
    int c = getState() - releases;
    //如果当前线程不是抢占锁的线程抛出异常
    if (Thread.currentThread() != getExclusiveOwnerThread())
        throw new IllegalMonitorStateException();
    boolean free = false;
    //占用锁的线程:c==0时，不是重入，那么就直接释放掉
    if (c == 0) {
        free = true;
        setExclusiveOwnerThread(null);
    }
    //重入次数减1
    setState(c);
    //重入释放失败，不是重入则释放成功
    return free;
}

private void unparkSuccessor(Node node) {
    /*
         * If status is negative (i.e., possibly needing signal) try
         * to clear in anticipation of signalling.  It is OK if this
         * fails or if status is changed by waiting thread.
         */
    //头结点恢复waitStatus的值为0
    int ws = node.waitStatus;
    if (ws < 0)
        compareAndSetWaitStatus(node, ws, 0);

    /*
         * Thread to unpark is held in successor, which is normally
         * just the next node.  But if cancelled or apparently null,
         * traverse backwards from tail to find the actual
         * non-cancelled successor.
         */
    Node s = node.next;
    //s==null，看下图就明白了，可能为null的
    if (s == null || s.waitStatus > 0) {
        s = null;
        //从tail--->head的方向遍历节点，为什么要这样，主要是插入的方式是先连接的前驱指针，看下图
        for (Node t = tail; t != null && t != node; t = t.prev)
            if (t.waitStatus <= 0)
                s = t;
    }
    //s!=null，说明找到了要唤醒的节点，唤醒该节点
    if (s != null)
        LockSupport.unpark(s.thread);
}
```

![image-20230817162543276](C:\Users\李玉伟\AppData\Roaming\Typora\typora-user-images\image-20230817162543276.png)

```html
由于插入节点的方式是先连接前驱节点，所以在多线程并发的环境下，可能会出现next指针还没有指向后继节点的情况，所以为了保证指针链不断裂，需要从后往前进行遍历。从当前node节点的前驱节点开始找到第一个waitStatus<=0的节点，与node节点连接起来。
```

## 非公平锁模式

**获取锁的流程**

```java
public void lock() {
    sync.lock();
    //调用下方的lock()方法
}
//NonfairSync中lock方法
final void lock() {
    //非公平锁上来先尝试修改state的值，如果抢占成功，把当前线程设置为占有锁的线程
    if (compareAndSetState(0, 1))
        setExclusiveOwnerThread(Thread.currentThread());
    else
        //抢占失败，那么就使用acquire()方法获取锁
        //acquire()方法是AQS中的方法，FairSync和NonfairSync调用的一样，区别在于tryAcquire方法不同
        acquire(1);
}
//NonfairSync中的tryAcquire方法会调用到Sync（FairSync和NonfairSync的父类）实现的nonfairTryAcquire方法
protected final boolean tryAcquire(int acquires) {
    return nonfairTryAcquire(acquires);
}
//
final boolean nonfairTryAcquire(int acquires) {
    final Thread current = Thread.currentThread();
    int c = getState();
    if (c == 0) {
        //和FairSync中的主要区别在于FairSync会先判断队列中是否有前驱节点在排队，而NonfairSync则不会判断，直接上来就先尝试CAS进行乐观锁抢占
        if (compareAndSetState(0, acquires)) {
            setExclusiveOwnerThread(current);
            return true;
        }
    }
    else if (current == getExclusiveOwnerThread()) {
        int nextc = c + acquires;
        if (nextc < 0) // overflow
            throw new Error("Maximum lock count exceeded");
        setState(nextc);
        return true;
    }
    return false;
}
//acquire中其他未分析的方法同公平锁一致
```

- **释放锁流程**

  释放锁流程公平锁和非公平锁一样，参考公平锁即可

  

## 公平锁和非公平锁共有的方法

```java
public void lockInterruptibly() throws InterruptedException {
    //acquireInterruptibly是AQS中的final方法
    //FairSync和NonfairSync共有这个方法
    sync.acquireInterruptibly(1);
}

public final void acquireInterruptibly(int arg)
    throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    //先使用tryAcquire方法尝试获取一下
    if (!tryAcquire(arg))
        //获取失败，进入该方法中
        doAcquireInterruptibly(arg);
}

private void doAcquireInterruptibly(int arg)
    throws InterruptedException {
    final Node node = addWaiter(Node.EXCLUSIVE);
    boolean failed = true;
    try {
        for (;;) {
            final Node p = node.predecessor();
            if (p == head && tryAcquire(arg)) {
                setHead(node);
                p.next = null; // help GC
                failed = false;
                return;
            }
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                //和acquireQueued方法的主要区别是这里如果线程在阻塞期间被中断过，被唤醒后抛出中断异常
                throw new InterruptedException();
        }
    } finally {
        //被唤醒后抛出中断异常后，进入到cancelAcquire方法
        if (failed)
            cancelAcquire(node);
    }
}

private void cancelAcquire(Node node) {
    // Ignore if node doesn't exist
    if (node == null)
        return;
	//节点线程置null
    node.thread = null;

    // Skip cancelled predecessors
    Node pred = node.prev;
    while (pred.waitStatus > 0)
        node.prev = pred = pred.prev;

    // predNext is the apparent node to unsplice. CASes below will
    // fail if not, in which case, we lost race vs another cancel
    // or signal, so no further action is necessary.
    Node predNext = pred.next;

    // Can use unconditional write instead of CAS here.
    // After this atomic step, other Nodes can skip past us.
    // Before, we are free of interference from other threads.
    node.waitStatus = Node.CANCELLED;

    // If we are the tail, remove ourselves.
    if (node == tail && compareAndSetTail(node, pred)) {
        compareAndSetNext(pred, predNext, null);
    } else {
        // If successor needs signal, try to set pred's next-link
        // so it will get one. Otherwise wake it up to propagate.
        int ws;
        if (pred != head &&
            ((ws = pred.waitStatus) == Node.SIGNAL ||
             (ws <= 0 && compareAndSetWaitStatus(pred, ws, Node.SIGNAL))) &&
            pred.thread != null) {
            Node next = node.next;
            if (next != null && next.waitStatus <= 0)
                compareAndSetNext(pred, predNext, next);
        } else {
            unparkSuccessor(node);
        }

        node.next = node; // help GC
    }
}
```



## Semaphore中的

构造方法

```java
//默认使用的是非公平锁
public Semaphore(int permits) {
    sync = new NonfairSync(permits);
}
//通过fair控制公平锁还是非公平锁
public Semaphore(int permits, boolean fair) {
    sync = fair ? new FairSync(permits) : new NonfairSync(permits);
}
```

公平锁模式

获取信号量方法

```java
public void acquire() throws InterruptedException {
    sync.acquireSharedInterruptibly(1);
}

//
public final void acquireSharedInterruptibly(int arg)
    throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    //tryAcquireShared()方法返回值大于等于0，则表明获取信号量成功，否则获取信息量失败，进入doAcquireSharedInterruptibly()方法中
    if (tryAcquireShared(arg) < 0)
        doAcquireSharedInterruptibly(arg);
}

protected int tryAcquireShared(int acquires) {
    // 自旋锁
    for (;;) {
        //先判断队列中是否有节点已经在排队了，如果有则失败
        if (hasQueuedPredecessors())
            return -1;
        //获取state剩余值
        int available = getState();
        int remaining = available - acquires;
        //remaining<0则失败
        //CAS如果成功，则获取信号量成功，返回剩余信号量，否则就重新自旋
        if (remaining < 0 ||
            compareAndSetState(available, remaining))
            return remaining;
    }
}

private void doAcquireSharedInterruptibly(int arg)
    throws InterruptedException {
    //addWaiter方法则是为当前线程构造节点，并且将当前线程加入到队列的尾部，并返回当前线程节点
    final Node node = addWaiter(Node.SHARED);
    boolean failed = true;
    try {
        for (;;) {
            final Node p = node.predecessor();
            //如果当前线程的前驱节点是头结点
            if (p == head) {
                //尝试获取一次，if r>=0,获取信号量成功
                int r = tryAcquireShared(arg);
                if (r >= 0) {
                    
                    setHeadAndPropagate(node, r);
                    p.next = null; // help GC
                    failed = false;
                    return;
                }
            }
            //同之前分析
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                throw new InterruptedException();
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}
```

释放信号量

```java
public void release() {
    sync.releaseShared(1);
}
public final boolean releaseShared(int arg) {
    //释放信号量
    if (tryReleaseShared(arg)) {
        doReleaseShared();
        return true;
    }
    //释放失败，则返回false,看CountDownLantch#countDown方法
    return false;
}

protected final boolean tryReleaseShared(int releases) {
    //自旋锁的方式释放信号量
    //释放后信号量的值 + releases
    for (;;) {
        int current = getState();
        int next = current + releases;
        if (next < current) // overflow
            throw new Error("Maximum permit count exceeded");
        if (compareAndSetState(current, next))
            return true;
    }
}
private void doReleaseShared() {
    /*
         * Ensure that a release propagates, even if there are other
         * in-progress acquires/releases.  This proceeds in the usual
         * way of trying to unparkSuccessor of head if it needs
         * signal. But if it does not, status is set to PROPAGATE to
         * ensure that upon release, propagation continues.
         * Additionally, we must loop in case a new node is added
         * while we are doing this. Also, unlike other uses of
         * unparkSuccessor, we need to know if CAS to reset status
         * fails, if so rechecking.
         */
    for (;;) {
        Node h = head;
        if (h != null && h != tail) {
            int ws = h.waitStatus;
            if (ws == Node.SIGNAL) {
                if (!compareAndSetWaitStatus(h, Node.SIGNAL, 0))
                    continue;            // loop to recheck cases
                unparkSuccessor(h);
            }
            else if (ws == 0 &&
                     !compareAndSetWaitStatus(h, 0, Node.PROPAGATE))
                continue;                // loop on failed CAS
        }
        if (h == head)                   // loop if head changed
            break;
    }
}
```



## CountDownLatch

```java
public CountDownLatch(int count) {
    if (count < 0) throw new IllegalArgumentException("count < 0");
    this.sync = new Sync(count);
}
```

```java
public void await() throws InterruptedException {
    sync.acquireSharedInterruptibly(1);
}

public final void acquireSharedInterruptibly(int arg)
    throws InterruptedException {
    if (Thread.interrupted())
        throw new InterruptedException();
    //tryAcquireShared()方法是判断计数器是否等于0，如果已经等于0了，那么调用await方法直接就返回了，否则就需要考虑阻塞调用await方法的线程
    if (tryAcquireShared(arg) < 0)
        //state!=0,那么进入该方法中，
        doAcquireSharedInterruptibly(arg);
}
//state的值不等于0，说明还有线程未调用countDown方法，当前线程需要等待，否则直接退出
protected int tryAcquireShared(int acquires) {
    return (getState() == 0) ? 1 : -1;
}

private void doAcquireSharedInterruptibly(int arg)
    throws InterruptedException {
    final Node node = addWaiter(Node.SHARED);
    boolean failed = true;
    try {
        for (;;) {
            final Node p = node.predecessor();
            if (p == head) {
                //如果r==1,那么计数器已经为0
                int r = tryAcquireShared(arg);
                if (r >= 0) {
                    setHeadAndPropagate(node, r);
                    p.next = null; // help GC
                    failed = false;
                    return;
                }
            }
            if (shouldParkAfterFailedAcquire(p, node) &&
                parkAndCheckInterrupt())
                throw new InterruptedException();
        }
    } finally {
        if (failed)
            cancelAcquire(node);
    }
}

private void setHeadAndPropagate(Node node, int propagate) {
    Node h = head; // Record old head for check below
    //将node设置为新的头节点
    setHead(node);
    /*
         * Try to signal next queued node if:
         *   Propagation was indicated by caller,
         *     or was recorded (as h.waitStatus either before
         *     or after setHead) by a previous operation
         *     (note: this uses sign-check of waitStatus because
         *      PROPAGATE status may transition to SIGNAL.)
         * and
         *   The next node is waiting in shared mode,
         *     or we don't know, because it appears null
         *
         * The conservatism in both of these checks may cause
         * unnecessary wake-ups, but only when there are multiple
         * racing acquires/releases, so most need signals now or soon
         * anyway.
         */
    if (propagate > 0 || h == null || h.waitStatus < 0 ||
        (h = head) == null || h.waitStatus < 0) {
        Node s = node.next;
        if (s == null || s.isShared())
            doReleaseShared();
    }
}
```

```java
public void countDown() {
    sync.releaseShared(1);
}

public final boolean releaseShared(int arg) {
    if (tryReleaseShared(arg)) {
        //state的值是0，那么可以唤醒队列中阻塞的线程了
        doReleaseShared();
        return true;
    }
    //计数器state还不是0，返回false
    return false;
}

protected boolean tryReleaseShared(int releases) {
    // Decrement count; signal when transition to zero
    for (;;) {
        //获取state
        int c = getState();
        //state的取值已经是0，返回false
        if (c == 0)
            return false;
        //c!=0, 
        int nextc = c-1;
        //修改state的值 ，修改成功后
        if (compareAndSetState(c, nextc))
            //剩余值是否0
            return nextc == 0;
    }
}
}

private void doReleaseShared() {
    /*
         * Ensure that a release propagates, even if there are other
         * in-progress acquires/releases.  This proceeds in the usual
         * way of trying to unparkSuccessor of head if it needs
         * signal. But if it does not, status is set to PROPAGATE to
         * ensure that upon release, propagation continues.
         * Additionally, we must loop in case a new node is added
         * while we are doing this. Also, unlike other uses of
         * unparkSuccessor, we need to know if CAS to reset status
         * fails, if so rechecking.
         */
    for (;;) {
        Node h = head;
        if (h != null && h != tail) {
            int ws = h.waitStatus;
            if (ws == Node.SIGNAL) {
                if (!compareAndSetWaitStatus(h, Node.SIGNAL, 0))
                    continue;            // loop to recheck cases
                unparkSuccessor(h);
            }
            else if (ws == 0 &&
                     !compareAndSetWaitStatus(h, 0, Node.PROPAGATE))
                continue;                // loop on failed CAS
        }
        if (h == head)                   // loop if head changed
            break;
    }
}
```

